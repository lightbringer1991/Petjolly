<?php
/**
* @project ApPHP Medical Appointment
* @copyright (c) 2012 - 2014 ApPHP
* @author ApPHP <info@apphp.com>
* @license http://www.gnu.org/licenses/
*/

    draw_title_bar(_DOCTORS);
    draw_important_message(_PAGE_NOT_EXISTS);
?>