<?php

/***
 *	Class Admins
 *  -------------- 
 *  Description : encapsulates account properties
 *	Written by  : ApPHP
 *	Version     : 1.0.2
 *  Updated	    : 21.10.2013
 *  Usage       : Core Class (excepting MicroBlog)
 *	Differences : no
 *
 *	PUBLIC:				  	STATIC:				 	PRIVATE:
 * 	------------------	  	---------------     	---------------
 **/

class Admins extends Accounts {


}

?>