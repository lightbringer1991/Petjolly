<?php

    define('DATABASE_HOST', 'localhost');             // Database host
    define('DATABASE_NAME', 'petdaddy');             // Name of the database to be used
    define('DATABASE_USERNAME', 'root');         // User name for access to database
    define('DATABASE_PASSWORD', '');     // Password for access to database
    
    define('DB_PREFIX', 'meda_');		          // Unique prefix of all tables in the database

    define('INSTALLATION_KEY', 'cgx1fos0yc'); // Unique key for installation
    
    define('PASSWORDS_ENCRYPTION_TYPE',  'MD5');  // AES|MD5
    define('PASSWORDS_ENCRYPTION',  true);              // true|false
    define('PASSWORDS_ENCRYPT_KEY', 'apphp_medical_appointment');           // encrypt key
    
?>