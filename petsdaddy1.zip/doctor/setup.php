<?php
include_once('templates/'.Application::Get('provider_template').'/default.php');
include_once('doctor/addListingPage.php');
?>
